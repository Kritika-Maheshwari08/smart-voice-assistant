# 🎙️ Kritika's Voice Assistant

Control your digital world with just your voice — meet Kritika’s smart assistant!  
Speak up `Quit` or `Exit` for ending... Let's Begin! ✨

## 🚀 Features

- Voice-controlled search using Speech Recognition 🎧
- Fetch summaries from Wikipedia 📖
- Text-to-speech feedback using pyttsx3 🗣️
- Smart greetings based on current time 🕒

## 🛠️ How to Run

1. Clone the repo
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the assistant:
   ```bash
   python assistant.py
   ```

---

🔗 **Live Demo:** _Not available as this is a local Python-based voice assistant._  
✅ Best experienced on your local machine.

---

Made with ❤️ by Kritika
